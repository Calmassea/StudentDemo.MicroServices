﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentDemo.AuthenticationCenterIds4.Models.Entities
{
    /// <summary>
    /// 用户角色表
    /// </summary>
    public class UserRole
    {
        //
        // 摘要:
        //     Gets or sets the primary key of the user that is linked to a role.
        public virtual string UserId
        {
            get;
            set;
        }

        //
        // 摘要:
        //     Gets or sets the primary key of the role that is linked to the user.
        public virtual string RoleId
        {
            get;
            set;
        }
    }
}
