﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace StudentDemo.AuthenticationCenterIds4.Models.Entities
{
    /// <summary>
    /// 用户表
    /// </summary>
    public class UserInfo
    {
        public UserInfo()
        {
            Id = Guid.NewGuid().ToString();
        }
        [Key]
        public string Id { get; set; } = Guid.NewGuid().ToString();
        [MaxLength(30)]
        [RegularExpression("^[A-Za-z0-9]+$", ErrorMessage = "不允许输入中文和特殊符号")]//限制用户输入特殊符号
        public string UserName { get; set; }
        [EmailAddress(ErrorMessage ="请输入正确的邮箱地址")]
        public string Email { get; set; }
        [RegularExpression(@"^[A-Z]+[a-z]+[a-zA-Z0-9""'\s-]+[^%&',;=?$\x22]*$", ErrorMessage = "密码必须包括字母大小写，数字，和一个或多个特殊符号！")]//限制用户输入特殊符号
        public string Password { get; set; }
        [RegularExpression(@"^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$",ErrorMessage ="请输入正确电话号码")]
        public string Phone { get; set; }
    }
}
