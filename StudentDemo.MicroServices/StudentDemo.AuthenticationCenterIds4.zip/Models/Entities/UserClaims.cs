﻿
using System.Security.Claims;
namespace StudentDemo.AuthenticationCenterIds4.Models.Entities
{
    public class UserClaims
    {
        //
        // 摘要:
        //     Gets or sets the identifier for this user claim.
        public virtual int Id
        {
            get;
            set;
        }

        //
        // 摘要:
        //     Gets or sets the primary key of the user associated with this claim.
        public virtual string UserId
        {
            get;
            set;
        }

        //
        // 摘要:
        //     Gets or sets the claim type for this claim.
        public virtual string ClaimType
        {
            get;
            set;
        }

        //
        // 摘要:
        //     Gets or sets the claim value for this claim.
        public virtual string ClaimValue
        {
            get;
            set;
        }

        //
        // 摘要:
        //     Converts the entity into a Claim instance.
        public virtual Claim ToClaim()
        {
            return new Claim(ClaimType, ClaimValue);
        }

        //
        // 摘要:
        //     Reads the type and value from the Claim.
        //
        // 参数:
        //   claim:
        public virtual void InitializeFromClaim(Claim claim)
        {
            ClaimType = claim.Type;
            ClaimValue = claim.Value;
        }
    }
}
